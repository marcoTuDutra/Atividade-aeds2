//
// Created by marco on 14/10/2022.
//

#ifndef PROVA01_SELECAO_H
#define PROVA01_SELECAO_H

int selecaoNatural(FILE *arq);

#endif //PROVA01_SELECAO_H
