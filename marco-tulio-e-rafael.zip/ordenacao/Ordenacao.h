//
// Created by marco on 14/10/2022.
//

#ifndef PROVA01_ORDENACAO_H
#define PROVA01_ORDENACAO_H

void keySort(FILE *arq, int size, float *tempoExecucao);
void insertionSort(FILE *arq, int size, float *tempoExecucao);
void arvoreBinariaVenc(int qtdParticoes, float *tempoExecucao);

#endif //PROVA01_ORDENACAO_H
